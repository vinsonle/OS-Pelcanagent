
/* Equal input range slider and its input text value */

    var slide_org_mortgage_payment = document.getElementById("org_mortgage_payment");
    var output_out_org_mortgage_payment = document.getElementById("out_org_mortgage_payment");
    output_out_org_mortgage_payment.value = slide_org_mortgage_payment.value;

    slide_org_mortgage_payment.oninput = function() {
        output_out_org_mortgage_payment.value = this.value;
    }

    var slider_cashout_amount = document.getElementById("cashout_amount");
    var output_out_cashout_amount = document.getElementById("out_cashout_amount");
    output_out_cashout_amount.value = slider_cashout_amount.value;

    slider_cashout_amount.oninput = function() {
        output_out_cashout_amount.value = this.value;
    }
    
    var slider_out_org_term_mortgage = document.getElementById("org_term_mortgage");
    var output_out_org_term_mortgage = document.getElementById("out_org_term_mortgage");
    output_out_org_term_mortgage.value = slider_out_org_term_mortgage.value;

    slider_out_org_term_mortgage.oninput = function() {
        output_out_org_term_mortgage.value = this.value;
    }

    var slider_org_monthly_int_rate = document.getElementById("org_monthly_int_rate");
    var output_out_org_monthly_int_rate = document.getElementById("out_org_monthly_int_rate");
    output_out_org_monthly_int_rate.value = slider_org_monthly_int_rate.value;

    slider_org_monthly_int_rate.oninput = function() {
        output_out_org_monthly_int_rate.value = this.value;
    }

    var slider_closing_costs = document.getElementById("closing_costs");
    var output_out_closing_costs = document.getElementById("out_closing_costs");
    output_out_closing_costs.value = slider_closing_costs.value;

    slider_closing_costs.oninput = function() {
        output_out_closing_costs.value = this.value;
    }

    var slider_new_monthly_int_rate = document.getElementById("new_monthly_int_rate");
    var output_out_new_monthly_int_rate = document.getElementById("out_new_monthly_int_rate");
    output_out_new_monthly_int_rate.value = slider_new_monthly_int_rate.value;

    slider_new_monthly_int_rate.oninput = function() {
        output_out_new_monthly_int_rate.value = this.value;
    }

    var slider_terms_new_loan_months = document.getElementById("terms_new_loan_months");
    var output_out_terms_new_loan_months = document.getElementById("out_terms_new_loan_months");
    output_out_terms_new_loan_months.value = slider_terms_new_loan_months.value;

    slider_terms_new_loan_months.oninput = function() {
        output_out_terms_new_loan_months.value = this.value;
    }


    var slider_refinance_terms = document.getElementById("refinance_terms");
    var output_out_refinance_terms = document.getElementById("out_refinance_terms");
    output_out_refinance_terms.value = slider_refinance_terms.value;

    slider_refinance_terms.oninput = function() {
        output_out_refinance_terms.value = this.value;
    }




/* Monthly Mortgage calculation on change of side filters*/


    function refinance_calculator(val) {

        var out_org_mortgage_payment = document.getElementById('out_org_mortgage_payment').value;
        out_org_mortgage_payment = parseInt(out_org_mortgage_payment.replace(/,/g, ""));

        var out_org_term_mortgage = document.getElementById('out_org_term_mortgage').value;
        out_org_term_mortgage = parseInt(out_org_term_mortgage.replace(/,/g, ""));

        var out_org_monthly_int_rate = document.getElementById('out_org_monthly_int_rate').value;
        out_org_monthly_int_rate = parseFloat(out_org_monthly_int_rate.replace(/,/g, ""));
        
        var out_cashout_amount = document.getElementById('out_cashout_amount').value; 
        out_cashout_amount = parseInt(out_cashout_amount.replace(/,/g, ""));
        
        var out_closing_costs = document.getElementById('out_closing_costs').value;
        out_closing_costs = parseInt(out_closing_costs.replace(/,/g, ""));

        var out_new_monthly_int_rate = document.getElementById('out_new_monthly_int_rate').value;
        out_new_monthly_int_rate = parseFloat(out_new_monthly_int_rate.replace(/,/g, ""));

        var out_terms_new_loan_months = document.getElementById('out_terms_new_loan_months').value;
        out_terms_new_loan_months = parseInt(out_terms_new_loan_months.replace(/,/g, ""));

        var out_refinance_terms = document.getElementById('out_refinance_terms').value;
        out_refinance_terms = parseInt(out_refinance_terms.replace(/,/g, ""));
        
        
        var outstanding_balance = out_org_mortgage_payment*[1-(1+out_org_monthly_int_rate)-(out_org_term_mortgage-out_refinance_terms)]/out_org_monthly_int_rate;

        var new_payment = [(outstanding_balance+out_cashout_amount+out_closing_costs)*out_new_monthly_int_rate]/[1-(1+out_new_monthly_int_rate)-out_terms_new_loan_months];

        var monthly_saving = out_org_mortgage_payment-new_payment;

        var break_even_price = out_closing_costs/monthly_saving;

console.log('outstanding_balance', outstanding_balance);
console.log(new_payment);
console.log(monthly_saving);
console.log(break_even_price);
        
        // For calculating location tax

         var ajaxurl = "/wp-admin/admin-ajax.php";

        var data = {
            'action': 'mortgage_cal',
            'price': price,
            'downpay': downpay,
            'interest': interest,
            'home_ins': insurance,
            'home_assoc': home_assoc,
            'loc_tax': location_tax,
            'loan_term': loan_term,
            'monthly_mort': monthly_mort

        };

        $.post(ajaxurl, data, function(response) {
           
        });

    }


/* Load the citylist on key of location input */

    $('#location').keyup(function() {

        var location = $(this).val(); 

        var ajaxurl = "/wp-admin/admin-ajax.php";

        var data = {

            'action': 'mortgage_cal',
            'location': location,

        };

        $.post(ajaxurl, data, function(response) {
            $('.location').html(response);
        });
    });

    //location_tax
    jQuery('body').on('click', '#my_city', function(e) {
        e.preventDefault();
        var justify = jQuery(this).html();
        document.getElementById('location').value = justify;
        jQuery('.cities_popup').hide();


        var location = document.getElementById('location').value;
        // var location_tax = document.getElementById('location_tax').value;

        var ajaxurl = "/wp-admin/admin-ajax.php";

        var data = {
            'action': 'load_tax',
            'location': location,
            'justify': justify
        };

        $.post(ajaxurl, data, function(response) {
            document.getElementById('demo4').value = response;
            // alert(response);
        });
    });


    //location insurance
    jQuery('body').on('click', '#my_city', function(e) {
        e.preventDefault();
        var justify = jQuery(this).html();
        document.getElementById('location').value = justify;
        jQuery('.cities_popup').hide();


        var location = document.getElementById('location').value;
        var location_ins = document.getElementById('demo5').value;

        var price_home = document.getElementById('demo').value;
        price_home = price_home.replace(/,/g, "");


         var ajaxurl = "/wp-admin/admin-ajax.php";
        var data = {
            'action': 'load_ins',
            'loc_tax': location_ins,
            'location': location,
            'price': price_home,
            'justify': justify
        };

        $.post(ajaxurl, data, function(response) {
            var insurance_rate = response;
            // alert(response);

            var insurance_state = parseInt((price_home / 100) * insurance_rate);
            // console.log(insurance_state)
            document.getElementById('demo5').value = insurance_state;

        });
    });

