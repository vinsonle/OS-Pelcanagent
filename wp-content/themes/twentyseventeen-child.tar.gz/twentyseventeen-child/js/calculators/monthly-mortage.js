
/* Equal input range slider and its input text value */

    var slider = document.getElementById("myRange");
    var output = document.getElementById("demo");
    output.value = slider.value;

    slider.oninput = function() {
        output.value = this.value;
    }

    var slidertwo = document.getElementById("myRange2");
    var outputtwo = document.getElementById("demo2");
    outputtwo.value = slidertwo.value;

    slidertwo.oninput = function() {
        outputtwo.value = this.value;
    }

    var sliderthree = document.getElementById("myRange3");
    var outputthree = document.getElementById("demo3");
    outputthree.value = sliderthree.value;

    sliderthree.oninput = function() {
        outputthree.value = this.value;
    }

    var sliderfour = document.getElementById("myRange4");
    var outputfour = document.getElementById("demo4");
    outputfour.value = sliderfour.value;

    sliderfour.oninput = function() {
        outputfour.value = this.value;
    }

    var sliderfive = document.getElementById("myRange5");
    var outputfive = document.getElementById("demo5");
    outputfive.value = sliderfive.value;

    sliderfive.oninput = function() {
        outputfive.value = this.value;
    }

    var slidersix = document.getElementById("myRange6");
    var outputsix = document.getElementById("demo6");
    outputsix.value = slidersix.value;

    slidersix.oninput = function() {
        outputsix.value = this.value;
    }


/* Monthly Mortgage calculation on change of side filters*/


    function mon_mortage(val) {

        var price = document.getElementById('demo').value;
        price = price.replace(/,/g, "");

        var downpay = document.getElementById('demo2').value;
        downpay = downpay.replace(/,/g, "");

        var interest = document.getElementById('demo3').value;
        interest = interest.replace(/,/g, "");

        var location_tax_rate = document.getElementById('demo4').value; 
        location_tax_rate = location_tax_rate.replace(/,/g, "");
        
        var insurance = document.getElementById('demo5').value;
        insurance = insurance.replace(/,/g, "");

        var location = document.getElementById('location').value;
        location = location.replace(/,/g, "");

        var home_assoc_fee = document.getElementById('demo6').value;
        home_assoc_fee = home_assoc_fee.replace(/,/g, "");

        var loan_term = document.getElementById('loan_term').value;
        loan_term = loan_term.replace(/,/g, "");

        var principal = price - downpay;

        var location_tax = ((price / 100) * location_tax_rate) + Number(home_assoc_fee);

        var month_insurance = insurance / 12;

        var month_tax = location_tax / 12;

        var total_insurance = month_insurance * monthly_term;

        var total_tax = (month_tax * monthly_term) + Number(home_assoc_fee);

        var month_tax_fee = month_tax + Number(home_assoc_fee);

        var monthly_interest = (interest / 12) / 100;

        var monthly_term = loan_term * 12;

        var sum_of_pay = monthly_mort * monthly_term;

        var now = new Date();

        var currentYear = now.getFullYear();

        var maxYear = Number(currentYear) + Number(loan_term);

        var yearly_interest = interest / 100;
  
        var monthly_mort = Math.round((Number(principal) * Number(monthly_interest)) / (1 - (Math.pow((1 + Number(monthly_interest)), -Number(monthly_term)))) + (Number(location_tax) + Number(insurance)) / 12);

        var principal_interest = monthly_mort - (parseInt(month_tax_fee) + parseInt(month_insurance));

        $('.total-taxes_value').html("$" + Math.round(month_tax_fee));
        $('.total-home-insurance_value').html("$" + month_insurance);
        $('.mortgage-payment-total_value').html("$" + principal_interest);

        //Ammortization Table for month

        var result = "";

        result += "<table border='1'><tr><th>Month</th><th>Monthly payment</th><th>Interest</th><th>Principal</th><th>Balance</th>";

        var monthlyPayment = ((Number(principal) * Number(monthly_interest)) / (1 - (Math.pow((1 + Number(monthly_interest)), -Number(monthly_term)))));
          
        var balance = principal;
        var principal_arr = [];
        var interest_arr = [];
        var balance_arr = [];

        for (var count = 0; count < monthly_term; ++count) {

            //in-loop interest amount holder
            var interest_rate = 0;

            //in-loop monthly principal amount holder
            var monthlyPrincipal = 0;

            //start a new table row on each loop iteration
            result += "<tr align=center>";

            //display the month number in col 1 using the loop count variable
            result += "<td>" + (count + 1) + "</td>"

            result += "<td> $" + Math.round(monthlyPayment) + "</td>";

            interest_rate = balance * monthly_interest;

            result += "<td> $" + Math.round(interest_rate) + "</td>";
            interest_arr[count] = Number(Math.round(interest_rate));

            monthlyPrincipal = monthlyPayment - interest_rate;
            result += "<td> $" + Math.round(monthlyPrincipal) + "</td>";
            principal_arr[count] = Number(Math.round(monthlyPrincipal));

            if (monthlyPayment > balance) {

                balance = 0;

            } else {

                balance = balance - monthlyPrincipal;
            }

            result += "<td> $" + Math.round(balance) + "</td>";
            balance_arr[count] = Number(Math.round(balance));

            //end the table row on each iteration of the loop 
            result += "</tr>";

            //update the balance for each loop iteration

        }

        //Final piece added to return string before returning it - closes the table
        result += "</table>";

        $('#ammort_table').html(result);

        //year wise amortization

        var result_year = "";

        result_year += "<table border='1'><tr><th> Year</th><th>Yearly payment</th><th>Interest</th><th>Principal</th><th>Balance</th>";

        var monthlyPayment = ((Number(principal) * Number(monthly_interest)) / (1 - (Math.pow((1 + Number(monthly_interest)), -Number(monthly_term)))));

        var balance = principal;
        var yearlyPayment = monthlyPayment * 12;
        var yearly_principal_arr = [];
        var yearly_interest_arr = [];
        var yearly_balance_arr = [];

        for (var count = 0; count < loan_term; ++count) {

            //in-loop interest amount holder
            var yearly_interest_rate = 0;

            //in-loop monthly principal amount holder
            var yearlyPrincipal = 0;

            var nextbalance = 0;
            
            //start a new table row on each loop iteration
            result_year += "<tr align=center>";

            //display the month number in col 1 using the loop count variable
            result_year += "<td>" + (count + 1) + "</td>"

            result_year += "<td> $" + yearlyPayment.toFixed(2) + "</td>";

            yearly_interest_rate = balance * yearly_interest;

            // alert(yearly_interest_rate);
            result_year += "<td> $" + yearly_interest_rate.toFixed(2) + "</td>";
            yearly_interest_arr[count] = Number(yearly_interest_rate.toFixed(2));

            yearlyPrincipal = yearlyPayment - yearly_interest_rate;
            result_year += "<td> $" + yearlyPrincipal.toFixed(2) + "</td>";
            yearly_principal_arr[count] = Number(yearlyPrincipal.toFixed(2));

            balance = balance - yearlyPrincipal;
            result_year += "<td> $" + balance.toFixed(2) + "</td>";
            yearly_balance_arr[count] = Number(balance.toFixed(2));

            //end the table row on each iteration of the loop 
            result_year += "</tr>";

            //update the balance for each loop iteration

        }

        //Final piece added to return string before returning it - closes the table
        result_year += "</table>";

        var graph_principal_arr = [];
        var total_principal_arr = 0;

        for (i = 0; i < yearly_principal_arr.length; i++) {
            total_principal_arr = total_principal_arr + yearly_principal_arr[i];
            graph_principal_arr[i] = Number(total_principal_arr.toFixed(2));
        }

        var graph_interest_arr = [];
        var total_interest_arr = 0;

        for (i = 0; i < yearly_interest_arr.length; i++) {
            total_interest_arr = total_interest_arr + yearly_interest_arr[i];

            graph_interest_arr[i] = Number(total_interest_arr.toFixed(2));
        }

        //returns the concatenated string to the page
        // $('#ammort_year').html(result_year);

        //doughnut chart
        var chart = new CanvasJS.Chart("chartContainer2", {
            animationEnabled: true,
            title: {
                // text: "Email Categories",
                horizontalAlign: "left"
            },
            data: [{
                type: "doughnut",
                startAngle: 270,
                innerRadius: 90,
                indexLabelFontSize: 17,
                indexLabel: "",
                toolTipContent: "",
                dataPoints: [{
                    y: principal_interest,
                    color: "#54ba6c"
                }, {
                    y: month_insurance,
                    color: "#ef840f"
                }, {
                    y: month_tax_fee,
                    color: "#fccd03"
                }, ]
            }]
        });
        chart.render();
        //Doughnut cahrt ends

        //Line chart start

        Highcharts.chart('container', {
            yAxis: {
                min: 0,
                max: principal,
                title: {
                    text: ''
                }
            },
            xAxis: {
                min: currentYear,
                max: maxYear,
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle'
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    },
                    pointStart: 2018
                }
            },

            series: [{
                name: 'Principal',
                data: graph_principal_arr

            }, {
                name: 'Interest',
                data: graph_interest_arr

            }, {
                name: 'Remaining',
                data: yearly_balance_arr

            }],

            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        legend: {
                            layout: 'horizontal',
                            align: 'center',
                            verticalAlign: 'bottom'
                        }
                    }
                }]
            }

        });
        //line chart ends

        // For calculating location tax

         var ajaxurl = "/wp-admin/admin-ajax.php";

        var data = {
            'action': 'mortgage_cal',
            'price': price,
            'downpay': downpay,
            'interest': interest,
            'home_ins': insurance,
            'home_assoc': home_assoc,
            'loc_tax': location_tax,
            'loan_term': loan_term,
            'monthly_mort': monthly_mort

        };

        $.post(ajaxurl, data, function(response) {
           
        });

    }


/* Load the citylist on key of location input */

    $('#location').keyup(function() {

        var location = $(this).val(); 

        var ajaxurl = "/wp-admin/admin-ajax.php";

        var data = {

            'action': 'mortgage_cal',
            'location': location,

        };

        $.post(ajaxurl, data, function(response) {
            $('.location').html(response);
        });
    });

    //location_tax
    jQuery('body').on('click', '#my_city', function(e) {
        e.preventDefault();
        var justify = jQuery(this).html();
        document.getElementById('location').value = justify;
        jQuery('.cities_popup').hide();


        var location = document.getElementById('location').value;
        // var location_tax = document.getElementById('location_tax').value;

        var ajaxurl = "/wp-admin/admin-ajax.php";

        var data = {
            'action': 'load_tax',
            'location': location,
            'justify': justify
        };

        $.post(ajaxurl, data, function(response) {
            document.getElementById('demo4').value = response;
            // alert(response);
        });
    });


    //location insurance
    jQuery('body').on('click', '#my_city', function(e) {
        e.preventDefault();
        var justify = jQuery(this).html();
        document.getElementById('location').value = justify;
        jQuery('.cities_popup').hide();


        var location = document.getElementById('location').value;
        var location_ins = document.getElementById('demo5').value;

        var price_home = document.getElementById('demo').value;
        price_home = price_home.replace(/,/g, "");


         var ajaxurl = "/wp-admin/admin-ajax.php";
        var data = {
            'action': 'load_ins',
            'loc_tax': location_ins,
            'location': location,
            'price': price_home,
            'justify': justify
        };

        $.post(ajaxurl, data, function(response) {
            var insurance_rate = response;
            // alert(response);

            var insurance_state = parseInt((price_home / 100) * insurance_rate);
            // console.log(insurance_state)
            document.getElementById('demo5').value = insurance_state;

        });
    });

/* Mortgage calculation on load of page */

    
window.onload = function() {

    var price = document.getElementById('myRange').value;
    var downpay = document.getElementById('myRange2').value;
    var interest = document.getElementById('myRange3').value;
    var location_tax_rate = document.getElementById('myRange4').value;

    var insurance = document.getElementById('myRange5').value;
    var location = document.getElementById('location').value;
    var home_assoc_fee = document.getElementById('myRange6').value;
    var loan_term = document.getElementById('loan_term').value;
    
    var principal = price - downpay;

    var location_tax = ((price / 100) * location_tax_rate) + Number(home_assoc_fee);

    var month_insurance = insurance / 12;
    var month_tax = location_tax / 12;
    var total_insurance = month_insurance * monthly_term;
    var total_tax = (month_tax * monthly_term) + Number(home_assoc_fee);
    var month_tax_fee = month_tax + Number(home_assoc_fee);
    var monthly_interest = (interest / 12) / 100;
    var monthly_term = loan_term * 12;
    var sum_of_pay = monthly_mort * monthly_term;
    var now = new Date();
    var currentYear = now.getFullYear();
    var maxYear = Number(currentYear) + Number(loan_term);
    var yearly_interest = interest / 100;

    var monthly_mort = Math.round((Number(principal) * Number(monthly_interest)) / (1 - (Math.pow((1 + Number(monthly_interest)), -Number(monthly_term)))) + (Number(location_tax) + Number(insurance)) / 12);

    var principal_interest = monthly_mort - (parseInt(month_tax_fee) + parseInt(month_insurance));
         
             $('#mytexts').html(month_insurance);

    //doughnut chart on page load
    var chart = new CanvasJS.Chart("chartContainer2", {

        animationEnabled: true,
        title: {
            // text: "Email Categories",
            horizontalAlign: "left"
        },

        data: [{
            type: "doughnut",
            startAngle: 270,
            innerRadius: 90,
            indexLabelFontSize: 17,
            indexLabel: "",
            toolTipContent: "",
            dataPoints: [{
                y: principal_interest,
                color: "#54ba6c"
            }, {
                y: month_insurance,
                color: "#ef840f"
            }, {
                y: month_tax_fee,
                color: "#fccd03"
            }, ]
        }]
    });
    chart.render();

    //line chart
    var result_year = "";

    result_year += "<table border='1'><tr><th>year</th><th>yearly payment</th><th>Interest</th><th>Principal</th><th>Balance</th>";

    var monthlyPayment = Math.round((Number(principal) * Number(monthly_interest)) / (1 - (Math.pow((1 + Number(monthly_interest)), -Number(monthly_term)))));

    var balance = principal;
    var yearlyPayment = monthlyPayment * 12;


    var yearly_principal_arr = [];
    var yearly_interest_arr = [];
    var yearly_balance_arr = [];


    for (var count = 0; count < loan_term; ++count) {


        //in-loop interest amount holder
        var yearly_interest_rate = 0;

        //in-loop monthly principal amount holder
        var yearlyPrincipal = 0;

        //start a new table row on each loop iteration
        result_year += "<tr align=center>";

        //display the month number in col 1 using the loop count variable
        result_year += "<td>" + (count + 1) + "</td>"

        result_year += "<td> $" + yearlyPayment.toFixed(2) + "</td>";

        yearly_interest_rate = balance * yearly_interest;

        result_year += "<td> $" + yearly_interest_rate.toFixed(2) + "</td>";
        yearly_interest_arr[count] = Number(yearly_interest_rate.toFixed(2));

        yearlyPrincipal = yearlyPayment - yearly_interest_rate;
        result_year += "<td> $" + yearlyPrincipal.toFixed(2) + "</td>";
        yearly_principal_arr[count] = Number(yearlyPrincipal.toFixed(2));

        balance = balance - yearlyPrincipal;
        result_year += "<td> $" + balance.toFixed(2) + "</td>";
        yearly_balance_arr[count] = Number(balance.toFixed(2));

        //end the table row on each iteration of the loop 
        result_year += "</tr>";

        //update the balance for each loop iteration

    }

    //Final piece added to return string before returning it - closes the table
    result_year += "</table>";

    var graph_principal_arr = [];
    var total_principal_arr = 0;

    for (i = 0; i < yearly_principal_arr.length; i++) {
        total_principal_arr = total_principal_arr + yearly_principal_arr[i];

        graph_principal_arr[i] = Number(total_principal_arr.toFixed(2));
    }

    var graph_interest_arr = [];
    var total_interest_arr = 0;

    for (i = 0; i < yearly_interest_arr.length; i++) {
        total_interest_arr = total_interest_arr + yearly_interest_arr[i];

        graph_interest_arr[i] = Number(total_interest_arr.toFixed(2));
    }
   
    //returns the concatenated string to the page
     $('#ammort_table').html(result_year);


    //Line chart start


    var chart = Highcharts.chart('container', {
        yAxis: {
            min: 0,
            max: price,
            title: {
                text: ''
            }
        },
        xAxis: {
            min: currentYear,
            max: maxYear,
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle'
        },

        plotOptions: {
            series: {
                label: {
                    connectorAllowed: false
                },
                pointStart: 2018
            }
        },

        series: [{
            name: 'Principal',
            data: graph_principal_arr
        }, {
            name: 'Interest',
            data: graph_interest_arr
        }, {
            name: 'Remaining',
            data: yearly_balance_arr
        }],

        responsive: {
            rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    legend: {
                        layout: 'horizontal',
                        align: 'center',
                        verticalAlign: 'bottom'
                    }
                }
            }]
        }

    });

    var mortgage_price = price;


            var ajaxurl = "/wp-admin/admin-ajax.php";

    var data = {

        'action': 'mortgage_price_action',
        'price': mortgage_price,
    };

    $.post(ajaxurl, data, function(response) {
        
        $('.payment_head').append(response);

    });

    $('.total-taxes_value').html("$" + month_tax_fee);
    $('.total-home-insurance_value').html("$" + month_insurance);
    $('.mortgage-payment-total_value').html("$" + principal_interest);


}
