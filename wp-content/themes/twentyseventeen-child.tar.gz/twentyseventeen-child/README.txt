=== Twenty Seventeen Child ===
Contributors:  dandelionweb
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JEMTB4U8SYFL6
Requires at least: WordPress 4.7
Tested up to: WordPress 4.7.2
Version: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: child theme

== Description ==

A blank child theme for Twenty Seventeen. 

For more information about Twenty Seventeen please go to https://codex.wordpress.org/Twenty_Seventeen.

== Installation ==

1. Download the zip file from https://github.com/ruthmaude/twentyseventeen-child.
2. In your admin panel, go to Appearance -> Themes -> Add New -> Upload Theme -> Choose File.
3. Browse your computer for the twentyseventeen-child.zip file downloaded in step 1 above.
4. click Open -> Install Now -> Activate.
5. Go to https://codex.wordpress.org/Twenty_Seventeen for a guide on how to customize this theme.
6. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

Twenty Seventeen WordPress Theme, Copyright 2016 WordPress.org
Twenty Seventeen is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Twenty Seventeen bundles the following third-party resources:

HTML5 Shiv, Copyright 2014 Alexander Farkas
Licenses: MIT/GPL2
Source: https://github.com/aFarkas/html5shiv

jQuery scrollTo, Copyright 2007-2015 Ariel Flesler
License: MIT
Source: https://github.com/flesler/jquery.scrollTo

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Font Awesome icons, Copyright Dave Gandy
License: SIL Open Font License, version 1.1.
Source: http://fontawesome.io/

Bundled header image, Copyright Alvin Engler
License: CC0 1.0 Universal (CC0 1.0)
Source: https://unsplash.com/@englr?photo=bIhpiQA009k

== Changelog ==

= 1.0 =
* Released: February 11, 2017


Initial release
